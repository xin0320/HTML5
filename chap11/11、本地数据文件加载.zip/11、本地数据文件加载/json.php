{
    "weather": "rainy",
    "temp": "27",
    "city": "Shanghai"
}